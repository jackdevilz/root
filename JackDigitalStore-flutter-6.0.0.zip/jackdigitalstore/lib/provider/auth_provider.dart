import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:jackdigitalstore_app/model/account/user_model.dart';
import 'package:jackdigitalstore_app/screen/account/reset_password_screen.dart';
import 'package:jackdigitalstore_app/screen/pages.dart';
import 'package:jackdigitalstore_app/services/auth_api.dart';
import 'package:jackdigitalstore_app/session/session.dart';
import 'package:jackdigitalstore_app/utils/shared.dart';
import 'package:jackdigitalstore_app/utils/utility.dart';

enum StatusAuth {
  Uninitialized,
  Authenticated,
  Authenticating,
  Unauthenticated
}

class AuthProvider with ChangeNotifier {
  StatusAuth _status = StatusAuth.Uninitialized;
  StatusAuth get status => _status;

  String? countryCode = '+62';

  Future<bool> signIn(context,
      {required String username, String? password}) async {
    FocusScopeNode currentFocus = FocusScope.of(context);

    if (!currentFocus.hasPrimaryFocus) {
      currentFocus.unfocus();
    }
    if (username.isNotEmpty && password!.isNotEmpty) {
      try {
        _status = StatusAuth.Authenticating;
        await AuthAPI().loginByDefault(username, password).then((data) {
          print("log in");
          if (data['cookie'] != null) {
            _status = StatusAuth.Authenticated;
            print(json.encode(data['user']));
            UserModel user = UserModel.fromJson(data['user']);
            printLog(json.encode(user));
            Session.data.setString('password', password);
            Session().saveUser(user, data['cookie'], data['cookie_name']);
            printLog(data['cookie'], name: 'Cookie');
            Session.data.setString("login_type", 'username');

            Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(
                    builder: (BuildContext context) => HomeScreen()),
                (Route<dynamic> route) => false);
          } else {
            _status = StatusAuth.Unauthenticated;
            snackBar(context, message: data['message'], color: Colors.red);
          }
        });
        notifyListeners();
        return true;
      } catch (e) {
        _status = StatusAuth.Unauthenticated;
        notifyListeners();
        return false;
      }
    } else {
      snackBar(context, message: 'Username and password should not empty');
    }
    return false;
  }

  bool loadingCek = false;

  Future<bool> cekPasKey(context, {String? key, String? id}) async {
    loadingCek = true;
    notifyListeners();
    if (key!.isNotEmpty && id!.isNotEmpty) {
      try {
        await AuthAPI().checkPassKey(key, id).then((data) {
          if (data["ID"].toString() == id) {
            Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(
                    builder: (BuildContext context) => ResetPasswordScreen(
                          id: id,
                          keys: key,
                        )),
                (Route<dynamic> route) => false);
          } else {
            _showAlertDeleteConfirmation(context);
          }
          loadingCek = false;
          notifyListeners();
        });
      } catch (e) {
        return false;
      }
    }
    return false;
  }

  _showAlertDeleteConfirmation(BuildContext context) {
    SimpleDialog alert = SimpleDialog(
      contentPadding: EdgeInsets.symmetric(vertical: 10, horizontal: 5),
      children: [
        Container(
          margin: EdgeInsets.symmetric(horizontal: 5),
          child: Column(
            children: [
              TextStyles(
                value: "Your link is expired",
                size: 16,
                weight: FontWeight.bold,
              ),
              SizedBox(height: 20),
              TextStyles(
                value: "Please resubmit your email again",
                size: 14,
                weight: FontWeight.bold,
                isLine: false,
              ),
              Container(
                margin: EdgeInsets.only(top: 15),
                child: Row(
                  children: [
                    Expanded(
                      child: MaterialButton(
                        color: accentColor,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(5.0)),
                        elevation: 0,
                        height: 40,
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        child: TextStyles(
                          value: "Okay",
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  Future<bool> forgotPassword(context, {String? email}) async {
    if (email!.isNotEmpty) {
      try {
        await AuthAPI().sendEmailForgots(email);
      } catch (e) {
        return false;
      }
    }
    return false;
  }

  bool loadingReset = false;
  Future<bool> resetPassword(context,
      {String? id, String? password, String? key}) async {
    if (id!.isNotEmpty && password!.isNotEmpty) {
      loadingReset = true;
      notifyListeners();
      try {
        await AuthAPI().resetPasswords(id, password, key).then((data) {
          if (data["status"] == "success") {
            Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                    builder: (BuildContext context) => HomeScreen()));
            Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (BuildContext context) => LoginScreen()),
            );
          }
          loadingReset = false;
          notifyListeners();
        });
      } catch (e) {
        return false;
      }
    }
    return false;
  }

  Future<bool> signOut(context, {bool isFromDrawer = false}) async {
    // var auth = FirebaseAuth.instance;
    // final AccessToken accessToken = await FacebookAuth.instance.accessToken;

    Session().removeUser();
    // if (auth.currentUser != null) {
    //   await GoogleSignIn().signOut();
    // }
    // if (accessToken != null) {
    //   await FacebookAuth.instance.logOut();
    // }
    // home.isReload = true;

    if (!isFromDrawer)
      Navigator.pushReplacement(context,
          MaterialPageRoute(builder: (BuildContext context) => HomeScreen()));

    return true;
  }

  Future<bool> reLog(context, {String? username, String? password}) async {
    FocusScopeNode currentFocus = FocusScope.of(context);

    if (!currentFocus.hasPrimaryFocus) {
      currentFocus.unfocus();
    }
    try {
      _status = StatusAuth.Authenticating;
      await AuthAPI().loginByDefault(username, password).then((data) {
        print("reLogging");
        if (data['cookie'] != null) {
          _status = StatusAuth.Authenticated;
          print(json.encode(data['user']));
          UserModel user = UserModel.fromJson(data['user']);
          printLog(json.encode(user));
          Session.data.setString('password', password!);
          Session().saveUser(user, data['cookie'], data['cookie_name']);
          printLog(data['cookie'], name: 'Cookie');
        } else {
          _status = StatusAuth.Unauthenticated;
          /*snackBar(context, message: data['message'], color: Colors.red);*/
        }
      });
      notifyListeners();
      return true;
    } catch (e) {
      _status = StatusAuth.Unauthenticated;
      notifyListeners();
      return false;
    }
  }

  Future<bool> signInOTP(context, phone) async {
    try {
      _status = StatusAuth.Authenticating;
      await AuthAPI().loginByOTP(phone).then((data) {
        if (data.statusCode == 200) {
          final responseJson = json.decode(data.body);
          Session.data.setBool('isLogin', true);
          Session.data.setString("cookie", responseJson['cookie']);
          Session.data.setString("login_type", 'otp');

          if (responseJson['user'] != null &&
              responseJson['user'] != "User OTP") {
            Session.data.setString("firstname", responseJson['user']);
          } else {
            Session.data.setString("firstname", responseJson['user_login']);
          }
          Session.data.setString('password', responseJson['user_pass']);
          Session.data.setString('user_otp', responseJson['user_login']);

          Session.data.setInt("id", responseJson['wp_user_id']);
          _status = StatusAuth.Authenticated;

          notifyListeners();
          return true;
        } else {
          _status = StatusAuth.Unauthenticated;
          notifyListeners();
          return false;
        }
      });
      return true;
    } catch (e) {
      _status = StatusAuth.Unauthenticated;
      notifyListeners();
      return false;
    }
  }

  setStatusAuth(value) {
    _status = value;
    notifyListeners();
  }
}
