part of '../pages.dart';

class HomeScreen extends StatefulWidget {
  final List<GeneralSettingsModel>? intro;
  static const String id = 'home_screen';
  HomeScreen({this.intro});
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  var _bottomNavIndex = 0;
  int endTime = DateTime.now().millisecondsSinceEpoch + 1000 * 13330;
  final GlobalKey globalKeyOne = GlobalKey();
  final GlobalKey globalKeyTwo = GlobalKey();
  final GlobalKey globalKeyThree = GlobalKey();
  List<Widget> pageList = [];

  translate(String title) {
    AppLocalizations.of(context)!.translate(title);
  }

  @override
  void initState() {
    super.initState();
    pageList = <Widget>[
      HomeSegment(globalKeyTwo: globalKeyTwo, globalKeyThree: globalKeyThree),
      CategoriesScreen(
        withBackBtn: false,
      ),
      CartSegment(),
      // Session.data.getBool('isLogin') ? AccountScreen() : LoadingLogin()
      AccountScreen()
    ];
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      if (Session.data.getBool('tool_tip')!) {
        ShowCaseWidget.of(context)
            .startShowCase([globalKeyOne, globalKeyTwo, globalKeyThree]);
      }
    });
  }

  Future<bool> _onWillPop() {
    return showDialog(
      context: context,
      builder: (context) => AlertDialog(
          contentPadding: EdgeInsets.zero,
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(15.0))),
          insetPadding: EdgeInsets.all(0),
          content: Builder(
            builder: (context) {
              return Container(
                height: 150.h,
                width: 330.w,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      children: [
                        SizedBox(
                          height: 15,
                        ),
                        Text(
                          AppLocalizations.of(context)!
                              .translate('title_exit_alert')!,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontSize: responsiveFont(14),
                              fontWeight: FontWeight.w500),
                        ),
                        SizedBox(
                          height: 15,
                        ),
                        Text(
                          AppLocalizations.of(context)!
                              .translate('body_exit_alert')!,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontSize: responsiveFont(12),
                              fontWeight: FontWeight.w400),
                        ),
                      ],
                    ),
                    Container(
                        child: Column(
                      children: [
                        Container(
                          color: Colors.black12,
                          height: 2,
                        ),
                        Row(
                          children: [
                            Expanded(
                              flex: 2,
                              child: GestureDetector(
                                onTap: () => Navigator.of(context).pop(false),
                                child: Container(
                                  alignment: Alignment.center,
                                  padding: EdgeInsets.symmetric(vertical: 12),
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.only(
                                          bottomLeft: Radius.circular(15)),
                                      color: accentColor),
                                  child: Text(
                                    AppLocalizations.of(context)!
                                        .translate('no')!,
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.w500),
                                  ),
                                ),
                              ),
                            ),
                            Expanded(
                              flex: 2,
                              child: GestureDetector(
                                onTap: () => Navigator.of(context).pop(true),
                                child: Container(
                                  alignment: Alignment.center,
                                  padding: EdgeInsets.symmetric(vertical: 12),
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.only(
                                          bottomRight: Radius.circular(15)),
                                      color: Colors.white),
                                  child: Text(
                                    AppLocalizations.of(context)!
                                        .translate('yes')!,
                                    style: TextStyle(
                                        fontWeight: FontWeight.w500,
                                        color: accentColor),
                                  ),
                                ),
                              ),
                            )
                          ],
                        ),
                      ],
                    ))
                  ],
                ),
              );
            },
          )),
    ).then((value) => value as bool);
  }

  @override
  Widget build(BuildContext context) {
    final textNavbar = <String>["Home", 'Categories', "Cart", "Account"];

    return Consumer<AppNotifier>(
      builder: (context, value, child) => WillPopScope(
        onWillPop: _onWillPop,
        child: Scaffold(
          // backgroundColor: Colors.white,
          body: pageList[_bottomNavIndex],
          floatingActionButton: FloatingActionButton(
            backgroundColor: accentColor,
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => AllStoreScreen(),
                ),
              );
            },
            child: Container(
                child: Image.asset(
              'assets/images/home/Frame 3.png',
              width: 30,
            )),
          ),
          floatingActionButtonLocation:
              FloatingActionButtonLocation.centerDocked,
          bottomNavigationBar: AnimatedBottomNavigationBar.builder(
            backgroundColor: value.isDarkMode ? Colors.black45 : Colors.white,
            itemCount: navbarIcon.length,
            tabBuilder: (int index, bool isActive) {
              final color = isActive ? accentColor : Colors.grey[300];
              if (index == 3 && Session.data.getBool('tool_tip')!) {
                return ShowCaseView(
                    globalKey: globalKeyOne,
                    index: 0,
                    // shapeBorder: RoundedRectangleBorder(
                    //     borderRadius: BorderRadius.all(Radius.circular(100))),
                    description: !Session.data.getBool('isLogin')!
                        ? AppLocalizations.of(context)!.translate('tip_1')!
                        : AppLocalizations.of(context)!
                            .translate('tip_1_login')!,
                    child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          ImageIcon(
                            AssetImage(navbarIcon[index]),
                            color: color,
                          ),
                          const SizedBox(height: 4),
                          Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 8),
                              child: Text(
                                AppLocalizations.of(context)!.translate(
                                    textNavbar[index].toLowerCase())!,
                                style: TextStyle(
                                    fontSize: 10,
                                    color: value.isDarkMode
                                        ? Colors.white
                                        : Colors.black),
                              ))
                        ]));
              }
              return Column(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ImageIcon(
                    AssetImage(navbarIcon[index]),
                    color: color,
                  ),
                  const SizedBox(height: 4),
                  Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      child: Text(
                        AppLocalizations.of(context)!
                            .translate(textNavbar[index].toLowerCase())!,
                        style: TextStyle(
                            fontSize: 10,
                            color:
                                value.isDarkMode ? Colors.white : Colors.black),
                      ))
                ],
              );
            },
            activeIndex: _bottomNavIndex,
            gapLocation: GapLocation.center,
            notchSmoothness: NotchSmoothness.softEdge,
            onTap: (index) async {
              setState(() {
                if (index == 3 && Session.data.getBool('isLogin')!) {
                  Session.data.setString('role', '');
                  Session.data.setString('status_approval_vendor', '');
                }

                _bottomNavIndex = index;
              });
            },
            //other params
          ),
        ),
      ),
    );
  }
}
