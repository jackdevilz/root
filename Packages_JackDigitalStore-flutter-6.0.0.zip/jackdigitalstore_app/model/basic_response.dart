class BasicResponse {
  int? statusCode;
  String? message;

  BasicResponse(this.statusCode, this.message);
}