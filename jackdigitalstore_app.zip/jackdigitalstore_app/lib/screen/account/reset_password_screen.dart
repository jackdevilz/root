import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:provider/provider.dart';
import 'package:jackdigitalstore_app/provider/auth_provider.dart';
import 'package:jackdigitalstore_app/utils/shared.dart';
import 'package:jackdigitalstore_app/utils/utility.dart';

class ResetPasswordScreen extends StatefulWidget {
  final String? id;
  final String? keys;
  const ResetPasswordScreen({Key? key, this.id, this.keys}) : super(key: key);

  @override
  State<ResetPasswordScreen> createState() => _ResetPasswordScreenState();
}

class _ResetPasswordScreenState extends State<ResetPasswordScreen> {
  TextEditingController pass = new TextEditingController();
  TextEditingController confirmPass = new TextEditingController();
  AuthProvider? auth;
  bool notShowPassword = true;
  bool notShowConPassword = true;

  void cekPassword() {
    if (pass.text == confirmPass.text) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        context.read<AuthProvider>().resetPassword(context,
            id: widget.id, password: pass.text, key: widget.keys);
      });
    } else {
      snackBar(context, message: 'Password and confirm password must same');
    }
  }

  @override
  void initState() {
    super.initState();
    auth = Provider.of<AuthProvider>(context, listen: false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 5,
        shadowColor: Colors.grey.withOpacity(0.18),
        titleSpacing: 0,
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: Icon(
            Icons.arrow_back,
            color: Colors.black,
            size: 18,
          ),
        ),
        centerTitle: true,
        title: Text(
          "Reset Password",
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: Colors.black,
          ),
        ),
      ),
      body: Container(
        padding: EdgeInsets.all(10),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text("Please enter new password"),
          Container(
            height: 20,
          ),
          Text(
            "New Password",
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          Container(
            margin: EdgeInsets.only(top: 10),
            width: double.infinity,
            child: GreyText(
                password: true,
                hintText: "Enter new password",
                controllerTxt: pass,
                showPassword: notShowPassword),
          ),
          Text(
            "Confirm New Password",
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          Container(
            margin: EdgeInsets.only(top: 10),
            width: double.infinity,
            child: GreyText(
              password: true,
              hintText: "Enter confirm new password",
              controllerTxt: confirmPass,
              showPassword: notShowConPassword,
            ),
          ),
          Consumer<AuthProvider>(builder: (context, value, child) {
            return value.loadingReset
                ? Container(
                    width: double.infinity,
                    margin: EdgeInsets.symmetric(vertical: 16),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    decoration: BoxDecoration(
                        color: Colors.grey[200],
                        borderRadius: BorderRadius.circular(10)),
                    child: customLoading(),
                  )
                : Container(
                    width: double.infinity,
                    margin: EdgeInsets.symmetric(vertical: 15),
                    child: MaterialButton(
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.all(Radius.circular(5))),
                      color: accentColor,
                      onPressed: () {
                        cekPassword();
                      },
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        child: Text(
                          "DONE",
                          style: TextStyle(color: primaryColor),
                        ),
                      ),
                    ),
                  );
          }),
        ]),
      ),
    );
  }
}
