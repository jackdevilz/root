import 'package:flutter/material.dart';
import 'package:jackdigitalstore_app/session/session.dart';
import 'package:jackdigitalstore_app/utils/shared.dart';
import 'package:jackdigitalstore_app/utils/utility.dart';

class AppNotifier extends ChangeNotifier {
  Locale _appLocale = Locale('en');
  bool isDarkMode = false;

  int? selectedLocaleIndex = 0;

  Locale get appLocal => _appLocale;

  ThemeData? _themeData;
  ThemeData? getTheme() => _themeData;

  AppNotifier() {
    String themeMode = Session.data.getString('themeMode') ?? 'light';
    if (themeMode == 'light') {
      _themeData = lightTheme;
      isDarkMode = false;
    } else {
      print('setting dark theme');
      _themeData = darkTheme;
      isDarkMode = true;
    }
    notifyListeners();
  }

  final lightTheme = ThemeData.light().copyWith(
    appBarTheme: AppBarTheme(
      backgroundColor: Colors.white,
      titleTextStyle: TextStyle(color: Colors.black),
      iconTheme: IconThemeData(color: Colors.black),
      // actionsIconTheme:
    ),
    primaryColor: primaryColor,
  );

  final darkTheme = ThemeData.dark().copyWith(
    primaryColor: primaryColor,
  );

  void setDarkMode() async {
    printLog('DARK MODE ACTIVATED');
    _themeData = darkTheme;
    Session.data.setString('themeMode', 'dark');
    notifyListeners();
  }

  void setLightMode() async {
    printLog('LIGHT MODE ACTIVATED');
    _themeData = lightTheme;
    Session.data.setString('themeMode', 'light');
    notifyListeners();
  }
}
